
import { useState, useCallback } from 'react';
import { analyzeMedicalData as callGeminiApi } from '../services/geminiService';
import { AnalysisResult, ApiResponse, MedicalDataInput } from '../types';

interface UseGeminiReturn extends ApiResponse<AnalysisResult> {
  analyzeData: (input: MedicalDataInput, useSearchGrounding?: boolean) => Promise<void>;
}

const useGemini = (): UseGeminiReturn => {
  const [data, setData] = useState<AnalysisResult | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const analyzeData = useCallback(async (input: MedicalDataInput, useSearchGrounding: boolean = false) => {
    setLoading(true);
    setError(null);
    setData(null);

    let base64Data: string | null = null;
    let mimeType: string | null = null;

    if (input.imageFile) {
      try {
        const reader = new FileReader();
        const promise = new Promise<string>((resolve, reject) => {
          reader.onloadend = () => {
            if (typeof reader.result === 'string') {
              resolve(reader.result.split(',')[1]); // Get base64 part
            } else {
              reject(new Error('Failed to read file as base64 string.'));
            }
          };
          reader.onerror = reject;
          reader.readAsDataURL(input.imageFile);
        });
        base64Data = await promise;
        mimeType = input.imageFile.type;
      } catch (fileReadError) {
        console.error("Error reading file:", fileReadError);
        setError(fileReadError instanceof Error ? fileReadError.message : String(fileReadError));
        setLoading(false);
        return;
      }
    }
    
    try {
      const result = await callGeminiApi(
        input.patientNotes, 
        base64Data, 
        mimeType,
        useSearchGrounding
      );
      setData(result);
      if (result.doctorAnalysis.startsWith("Error:") || result.laymanSummary.startsWith("Error:")) {
        setError(result.doctorAnalysis); // Or a more combined error message
      }
    } catch (apiError) {
      console.error("Gemini API call failed:", apiError);
      setError(apiError instanceof Error ? apiError.message : String(apiError));
      setData(null);
    } finally {
      setLoading(false);
    }
  }, []);

  return { data, loading, error, analyzeData };
};

export default useGemini;
    