
import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { ImageFileState } from '../../types';
import { IconProps } from '../../types';

const DocumentArrowUpIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m.75 12 3 3m0 0 3-3m-3 3v-6m-1.5-9H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" />
  </svg>
);

const XCircleIcon: React.FC<IconProps> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="m9.75 9.75 4.5 4.5m0-4.5-4.5 4.5M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
  </svg>
);


interface FileUploadProps {
  onFileChange: (fileState: ImageFileState) => void;
  currentFileState: ImageFileState;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileChange, currentFileState }) => {
  const [error, setError] = useState<string | null>(null);

  const onDrop = useCallback((acceptedFiles: File[], rejectedFiles: any[]) => {
    setError(null);
    if (rejectedFiles && rejectedFiles.length > 0) {
        const firstError = rejectedFiles[0].errors[0];
        if (firstError.code === 'file-too-large') {
            setError("File is too large. Maximum size is 4MB.");
        } else if (firstError.code === 'file-invalid-type') {
            setError("Invalid file type. Please upload JPG, PNG, or PDF.");
        } else {
            setError(firstError.message || "File upload error.");
        }
        onFileChange({ file: null, previewUrl: null, base64: null });
        return;
    }

    if (acceptedFiles && acceptedFiles.length > 0) {
      const file = acceptedFiles[0];
      const reader = new FileReader();
      
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        let previewUrl = null;
        if (file.type.startsWith('image/')) {
            previewUrl = URL.createObjectURL(file);
        } else if (file.type === 'application/pdf') {
            // For PDFs, we might show a generic PDF icon or filename.
            // URL.createObjectURL can also work for PDFs in some browsers to link to them.
            previewUrl = 'pdf_icon_placeholder'; // Placeholder, actual icon handled in render
        }
        onFileChange({ file, previewUrl, base64: base64String });
      };
      
      reader.onerror = () => {
        setError("Failed to read file.");
        onFileChange({ file: null, previewUrl: null, base64: null });
      };
      
      reader.readAsDataURL(file);
    }
  }, [onFileChange]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'application/pdf': ['.pdf']
    },
    maxSize: 4 * 1024 * 1024, // 4MB
    multiple: false,
  });

  const removeFile = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent dropzone activation
    if (currentFileState.previewUrl && currentFileState.previewUrl !== 'pdf_icon_placeholder') {
        URL.revokeObjectURL(currentFileState.previewUrl);
    }
    onFileChange({ file: null, previewUrl: null, base64: null });
    setError(null);
  };

  return (
    <div className="space-y-2">
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors
                    ${isDragActive ? 'border-primary-DEFAULT bg-primary-light/10' : 'border-neutral-300 hover:border-primary-light'}`}
      >
        <input {...getInputProps()} />
        <DocumentArrowUpIcon className="h-12 w-12 mx-auto text-neutral-400 mb-2" />
        {isDragActive ? (
          <p className="text-primary-DEFAULT">Drop the file here ...</p>
        ) : (
          <p className="text-neutral-500">Drag 'n' drop a file here, or click to select</p>
        )}
        <p className="text-xs text-neutral-400 mt-1">JPG, PNG, PDF (Max 4MB)</p>
      </div>
      {error && <p className="text-sm text-red-600">{error}</p>}
      {currentFileState.file && (
        <div className="mt-3 p-3 border border-neutral-200 rounded-lg bg-neutral-50 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            {currentFileState.previewUrl === 'pdf_icon_placeholder' || currentFileState.file.type === 'application/pdf' ? (
              <DocumentArrowUpIcon className="h-10 w-10 text-red-500" /> // Basic PDF icon
            ) : (
              currentFileState.previewUrl && <img src={currentFileState.previewUrl} alt="Preview" className="h-16 w-16 object-cover rounded" />
            )}
            <div>
              <p className="text-sm font-medium text-neutral-700 truncate max-w-xs">{currentFileState.file.name}</p>
              <p className="text-xs text-neutral-500">{(currentFileState.file.size / 1024).toFixed(1)} KB</p>
            </div>
          </div>
          <button onClick={removeFile} className="p-1 text-neutral-500 hover:text-red-600">
            <XCircleIcon className="h-6 w-6" />
          </button>
        </div>
      )}
    </div>
  );
};

export default FileUpload;
    