
import React, { useEffect, useRef, useState } from 'react';

interface AnimatedSectionProps {
  children: React.ReactNode;
  className?: string;
  animationClass?: string; // e.g., 'animate-fade-in-up'
  delay?: string; // e.g., 'delay-200' for tailwind
}

const AnimatedSection: React.FC<AnimatedSectionProps> = ({ 
  children, 
  className = '', 
  animationClass = 'animate-fade-in-up',
  delay = '' 
}) => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    // For simplicity, this triggers on mount. 
    // A more complex version would use IntersectionObserver.
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 50); // Small delay to ensure CSS is ready

    return () => clearTimeout(timer);
  }, []);

  return (
    <div
      ref={sectionRef}
      className={`${className} ${isVisible ? `${animationClass} ${delay}` : 'opacity-0'} transition-opacity duration-500`}
    >
      {children}
    </div>
  );
};

export default AnimatedSection;
    