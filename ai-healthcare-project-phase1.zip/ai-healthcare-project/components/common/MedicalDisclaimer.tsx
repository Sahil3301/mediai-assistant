import React from 'react';

const MedicalDisclaimer: React.FC = () => {
  return (
    <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 my-4 rounded-md">
      <div className="flex">
        <div className="flex-shrink-0">
          <svg className="h-5 w-5 text-yellow-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
          </svg>
        </div>
        <div className="ml-3">
          <p className="text-sm text-yellow-700 font-medium">
            <strong>Medical Disclaimer:</strong> This AI tool is designed to assist medical professionals and is not a substitute for professional medical advice, diagnosis, or treatment. 
          </p>
          <p className="text-sm text-yellow-700 mt-1">
            Healthcare providers are advised to verify all AI-generated analyses before making clinical decisions or providing advice to patients. AI can make mistakes and should be used as a supportive tool only.
          </p>
          <p className="text-sm text-yellow-700 mt-1">
            <strong>AI Limitations:</strong> This system has several important limitations:
          </p>
          <ul className="list-disc pl-5 text-sm text-yellow-700 mt-1">
            <li>It may not have access to the most current medical research or guidelines</li>
            <li>It cannot physically examine patients or interpret nuanced clinical presentations</li>
            <li>It may occasionally generate incorrect or incomplete information</li>
            <li>It should never replace professional medical judgment or direct patient care</li>
          </ul>
          <p className="text-sm text-yellow-700 mt-1">
            Always consult with qualified healthcare professionals for medical concerns. By using this tool, you acknowledge these limitations and agree to use it responsibly.
          </p>
        </div>
      </div>
    </div>
  );
};

export default MedicalDisclaimer;
