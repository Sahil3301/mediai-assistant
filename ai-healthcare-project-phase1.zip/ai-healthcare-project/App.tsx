
import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import { RoutePath } from './constants';
import LandingPage from './pages/LandingPage'; // Correct relative path
import DashboardPage from './pages/DashboardPage'; // Correct relative path
import NotFoundPage from './pages/NotFoundPage'; // Correct relative path
import Header from './components/common/Header'; // Correct relative path
import Footer from './components/common/Footer'; // Correct relative path

const AppContent: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow">
        <Routes>
          <Route path={RoutePath.Home} element={<LandingPage />} />
          <Route path={RoutePath.Dashboard} element={<DashboardPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
};

const App: React.FC = () => {
  return (
    <HashRouter>
      <AppContent />
    </HashRouter>
  );
};

export default App;
